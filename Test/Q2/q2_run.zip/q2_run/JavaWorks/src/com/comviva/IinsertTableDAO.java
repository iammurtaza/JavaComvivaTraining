package com.comviva;

public interface IinsertTableDAO {
	public boolean insertEmployee(int empid, String empname, int empsal,
			String empemail);
}
