package com.test;

public interface IEmployeeDAO {
	public boolean insertEmployee();
}
